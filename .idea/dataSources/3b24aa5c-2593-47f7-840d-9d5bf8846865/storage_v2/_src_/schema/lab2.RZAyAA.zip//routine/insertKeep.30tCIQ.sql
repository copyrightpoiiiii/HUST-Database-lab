create
    definer = root@localhost procedure insertKeep(IN cid int, IN money int)
begin
    insert into keepRecord (carID, keepDate, money) VALUES (cid,date_format(now(), '%Y%m%d'),money);
end;


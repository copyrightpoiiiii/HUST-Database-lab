create
    definer = root@localhost procedure queryUserApply(IN name char(20))
begin
    select carID,id,brrowTime,receTime,state
    from applyRecord,userAuth
    where applyRecord.userID = userAuth.userID and userAuth.username=name;
end;


create
    definer = root@localhost procedure signIn(IN uname char(20), IN psd char(20), IN phoneNum char(22))
begin
    insert into userAuth (username,password,type) values (uname,psd,2);
    insert into userInfo values (-1,phoneNum,60,0,0,date_format(now(), '%Y%m%d'));
    update userInfo,userAuth
    set userInfo.id = userAuth.userID where id = -1 and username = uname;
end;


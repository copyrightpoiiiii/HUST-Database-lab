create
    definer = root@localhost procedure changeCarState(IN carid int, IN sta int)
begin
    if(sta = 1)then
        update carInfo set upkeepDate = date_format(now(), '%Y%m%d') where id = carid;
    end if ;
    update carInfo set useState = sta where id = carid;
end;


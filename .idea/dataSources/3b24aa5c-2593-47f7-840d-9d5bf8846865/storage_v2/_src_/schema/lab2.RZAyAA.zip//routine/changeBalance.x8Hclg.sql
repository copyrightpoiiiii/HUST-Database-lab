create
    definer = root@localhost procedure changeBalance(IN name char(20), IN num int)
begin
    update userInfo,userAuth set userInfo.balance = userInfo.balance + num where userInfo.id = userAuth.userID
                                                                             and userAuth.username = name;
end;


create
    definer = root@localhost procedure queryCarState()
begin
    select id,useTime,useDis,upkeepDate,city,useState
    from carInfo;
end;


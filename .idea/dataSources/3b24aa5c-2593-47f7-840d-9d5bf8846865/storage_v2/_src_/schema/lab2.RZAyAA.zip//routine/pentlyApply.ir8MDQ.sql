create
    definer = root@localhost procedure pentlyApply(IN inid int, IN crash int, IN fix int)
begin
    update applyRecord
    set fixNum = fixNum + fix,crashType = crash where inid = id;
end;


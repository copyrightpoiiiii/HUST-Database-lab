create definer = root@localhost trigger insertAR
    after insert
    on applyRecord
    for each row
begin
        set @tmp := 0;
        select count(*) into @tmp
            from applyRecord
                group by userID
                    having userID = NEW.userID;
        if (@tmp = 50 or @tmp = 150) then
            update userInfo set vipLevel = vipLevel + 1 where id = NEW.userID;
        end if;
    end;


create
    definer = root@localhost procedure userQueryApply(IN name char(18))
begin
    select id,carID,brrowTime,receTime,state
    from applyRecord,userAuth
    where userAuth.username = name and userAuth.userID = applyRecord.userID;
end;


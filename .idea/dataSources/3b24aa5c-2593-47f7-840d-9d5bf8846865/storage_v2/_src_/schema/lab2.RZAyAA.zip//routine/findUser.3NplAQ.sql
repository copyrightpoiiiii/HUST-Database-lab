create
    definer = root@localhost procedure findUser(IN name char(20))
begin
    select type
    from userAuth
    where username = name;
end;


create
    definer = root@localhost procedure deleteCar(IN carid int)
begin
    delete from carInfo where id = carid;
end;


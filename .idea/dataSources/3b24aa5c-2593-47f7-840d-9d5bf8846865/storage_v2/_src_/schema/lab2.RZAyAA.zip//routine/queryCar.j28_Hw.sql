create
    definer = root@localhost procedure queryCar(IN take int, IN cartype int, IN carpriceBegin int, IN carpriceEnd int,
                                                IN cityName char(18))
begin
    select  id,price,type,takeNum,city,useDis,useTime
    from    carInfo
        where takeNum>=take and cartype=type and (price between carpriceBegin and carpriceEnd) and
                city = cityName and useState = 0;
end;


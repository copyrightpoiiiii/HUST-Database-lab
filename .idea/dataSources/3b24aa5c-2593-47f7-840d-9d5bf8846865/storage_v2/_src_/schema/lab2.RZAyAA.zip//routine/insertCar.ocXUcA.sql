create
    definer = root@localhost procedure insertCar(IN take int, IN cartype int, IN carprice int, IN cityName char(18))
begin
    insert into carInfo (type,takeNum,price,city,useState,upkeepDate,useTime,useDis)
    values (cartype,take,carprice,cityName,0,curdate(),0,0);
end;


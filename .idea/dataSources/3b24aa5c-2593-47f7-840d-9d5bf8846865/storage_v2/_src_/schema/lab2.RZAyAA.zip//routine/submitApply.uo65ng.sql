create
    definer = root@localhost procedure submitApply(IN inid int, IN sta int, IN userid int)
begin
    update applyRecord
    set state = sta where inid = id;
    set @carid = 0;
    set @userid = 0;
    set @Money1 = 0 , @Money2 = 0 ,@vip = 0;
    select @Money1 := prePrice , @Money2 := carInfo.price , @vip := vipLevel
    from carInfo,applyRecord,userInfo
    where inid = applyRecord.id and applyRecord.carID = carInfo.id and applyRecord.userID = userInfo.id;
    select @carid := carID,@userid := userID
    from applyRecord
    where inid = id;
    update applyRecord set receTime = date_format(now(), '%Y%m%d'),managerID=userid where id = inid;
    if(sta = 3) then
        update carInfo
            set useState = 3 where id = @carid;
    elseif (sta = 4) then
        update carInfo
        set useState =0 where id = @carid;
        update userInfo
        set balance = balance - ROUND( @Money2 *(1-@vip*0.1)) + @Money1 ,credit =credit+1 where id=@userid;
        update applyRecord set price = ROUND( @Money2 *(1-@vip*0.1)) where id = inid;
        update carInfo set useTime = useTime + 1 ,useDis = useDis + 1000 where id = @carid;
    elseif (sta = 2) then
        update carInfo
        set useState =0 where id = @carid;
    end if ;
end;


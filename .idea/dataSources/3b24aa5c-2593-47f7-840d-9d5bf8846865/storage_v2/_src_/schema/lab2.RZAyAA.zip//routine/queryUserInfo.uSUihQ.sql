create
    definer = root@localhost procedure queryUserInfo(IN name char(20))
begin
    select credit,balance,vipLevel
        from userInfo,userAuth
            where userInfo.id = userAuth.userID and userAuth.username = name;
end;


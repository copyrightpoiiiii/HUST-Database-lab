create
    definer = root@localhost procedure makeTable(IN startDate date, IN endDate date, OUT carNum int, OUT keepCar int,
                                                 OUT v1 int, OUT v2 int, OUT v3 int, OUT keepFee int, OUT Fee int,
                                                 OUT fundSum int, OUT gain int)
begin
    set @tmp := 0;
    select @tmp := count(*) from carInfo where signDate >= startDate and signDate <= endDate;
    set carNum := @tmp;
    select @tmp := count(*) from carInfo where useState = 1 and (signDate >= startDate and signDate <= endDate);
    set keepCar := @tmp;
    select @tmp := count(*) from userInfo where vipLevel = 0 and (signDate >= startDate and signDate <= endDate);
    set v1 := @tmp;
    select @tmp := count(*) from userInfo where vipLevel = 1 and (signDate >= startDate and signDate <= endDate);
    set v2 := @tmp;
    select @tmp := count(*) from userInfo where vipLevel = 2 and (signDate >= startDate and signDate <= endDate);
    set v3 := @tmp;
    select @tmp := sum(money)
    from keepRecord
    where keepDate >= startDate and keepDate <= endDate;
    set keepFee := @tmp;
    select @tmp := sum(balance)
    from userInfo
    where signDate >= startDate and signDate <= endDate;
    set Fee := @tmp;
    set @tmp2 := 0;
    select @tmp := sum(fixNum),@tmp2 := sum(price)
    from applyRecord
        where receTime >= startDate and receTime <= endDate;
    set fundSum := @tmp;
    set gain := @tmp2;
end;


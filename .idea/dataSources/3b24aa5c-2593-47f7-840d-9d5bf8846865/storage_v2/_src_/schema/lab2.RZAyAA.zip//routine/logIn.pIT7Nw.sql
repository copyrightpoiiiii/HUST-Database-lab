create
    definer = root@localhost procedure logIn(IN name char(20), IN psd char(20))
begin
    select type
    from userAuth
    where username = name and psd = password;
end;


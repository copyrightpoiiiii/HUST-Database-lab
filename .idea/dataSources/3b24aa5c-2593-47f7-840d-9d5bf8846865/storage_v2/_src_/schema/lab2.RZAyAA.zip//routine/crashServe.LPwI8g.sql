create
    definer = root@localhost procedure crashServe(IN cid int, IN type int, IN money int)
begin
    set @carid := 0;
    update applyRecord set crashType = type,fixNum = money where cid = id;
    set @id := 0;
    select @id := userID,@carid := carID
    from applyRecord
    where cid = id;
    update userInfo set balance = balance - money where id = @id;
    update carInfo set useState = 4 where id=@carid;
end;


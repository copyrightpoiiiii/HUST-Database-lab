create
    definer = root@localhost procedure bookCar(IN carid int, IN name char(18), OUT sta int)
begin
    update carInfo set useState = 2 where id = carid;
    set @userid := 0,@userbalance := 0;
    set @dt = now();
    set @city := null,@pri := 0 ,@preMoney := 0;
    select @city := city,@preMoney := prePrice,@pri := price
    from carInfo
    where id = carid;
    select @userid:=userID,@userbalance := balance
    from userAuth,userInfo
    where username = name and id = userID;
    if(@userbalance >= @pri) then
        insert into applyRecord (userID,brrowTime,ssCity,price,carID,state,crashType,fixNum)
            values (@userid,date_format(@dt, '%Y%m%d'),@city,@pri,carid,1,0,0);
        update userinfo set balance = balance - @preMoney where  id = @userid;
        set sta := 1;
    else set sta := 0;
    end if ;
end;


create
    definer = root@localhost procedure queryApply()
begin
    select applyRecord.id,username,credit,phone,ssCity,state
    from applyRecord,userInfo,userAuth
    where (state = 3 or state = 1 or state = 4) and applyRecord.userID = userInfo.id and userInfo.id = userAuth.userID;
end;

